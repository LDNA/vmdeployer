#!/bin/bash

SCRIPT_PATH=$(dirname $(readlink -f $0))
$SCRIPT_PATH/bin/ld-linux-x86-64.so.2 --library-path $SCRIPT_PATH/bin $SCRIPT_PATH/bin/xmrig $* 

